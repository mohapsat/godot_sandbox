

	You can find the spritesheet for the 'Voxel pack' and 'Roguelike pack' in the /Tilesheet/ folder, as it's the same as a spritesheet.
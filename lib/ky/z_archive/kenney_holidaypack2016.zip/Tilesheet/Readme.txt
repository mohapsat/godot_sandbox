

	You can find the tilesheet for the 'Hexagon pack' in the /Spritesheet/ folder, as it's the same as a tilesheet.
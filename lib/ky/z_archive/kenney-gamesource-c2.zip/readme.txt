All graphics in these source files are made by Kenney and can be downloaded for free (license: CC Zero) from http://www.kenney.nl/
You can also donate to receive a complete package of all 5,000+ assets: http://kenney.itch.io/kenney-donation

These source files can be opened using Construct 2.

Construct 2 is a game maker for Windows that lets everyone create amazing games for a wide variety of platforms using HTML5.
I'm not endorsed by Construct 2, I just really like the program.

You can download a free version of the program here:
https://www.scirra.com/

or purchase a license here:
https://www.scirra.com/store